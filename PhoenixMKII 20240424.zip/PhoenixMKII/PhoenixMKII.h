
#define DEBUG_MODE 0
#define SENSOR_DEBUG_MODE 0

// LEFT
#define GPI_ADC_BAT 4
#define GPO_SSPI_SW 5
#define GPO_I2C_SW 6
#define I2C_SCL 7
#define I2C_SDA 15
#define GPO_I2CE_RES 16
#define GPIO_U1TX 17
#define GPIO_U1RX 18
#define GPO_DSP_RST 8
#define GPO_DSP_SW 3
#define GPO_SD_SW 46
#define GPI_SDD 9
#define FSPI_CS0 10
#define FSPI_MOSI 11
#define FSPI_CLK 12
#define FSPI_MISO 13
#define GPI_BT0 14

// RIGHT
#define TEMP_CS0 41
#define TEMP_CS1 40
#define TEMP_CS2 39
#define TEMP_CS3 38
#define SSPI_MISO 37
#define SSPI_CLK 36
#define TEMP_CS4 45
#define TEMP_CS5 48
#define TEMP_CS6 47
#define TEMP_CS7 21

#define LEDS_COUNT 1
#define LEDS_PIN 48
#define CHANNEL 0

#define TCAADDR 0x70       // I2C multiplexer
#define SSC_I2C_ADDR 0x28  // pressure sensor I2C address

#define ADC_R1 82          // replace this value with the final design value
#define ADC_R2 51          // replace this value with the final design value
#define ADC_CONSTANT 1024  // 10 bit ADC resolution. 2^10 = 1024
#define BAT_EMPTY 6.8      // replace with final design
#define BAT_FULL 12.0      // replace with final design

#define MAXMUM_FILE_SIZE 1024 * 1024

#define BUTTON_HOLD_TIMEOUT_SHORT_MS 1000
#define BUTTON_HOLD_TIMEOUT_LONG_MS 3000
#define FIRST_SCREEN_TIME_MS 60000
#define SECOND_SCREEN_TIME_MS 600000
#define TIME_ZONE_PLUS 0

#define TASK_QUEUE_SIZE 30

unsigned long debug_time_now = 0;  // used for "millis()" version of delay()
#define DELAY_MS(x) \
  debug_time_now = millis(); \
  while (millis() - debug_time_now < x) \
    ;

#define DEBUG_PRINT(x) \
  if (DEBUG_MODE) { \
    Serial0.print(x); \
  }

#define DEBUG_PRINTln(x) \
  if (DEBUG_MODE) { \
    Serial0.println(x); \
  }

#define DEBUG_PRINTf(x, ...) \
  if (DEBUG_MODE) { \
    Serial0.printf(x, __VA_ARGS__); \
  }

void Debug_init() {
  if (DEBUG_MODE) {
    Serial0.begin(115200);
    while (!Serial0)
      delay(1);  // wait for Serial get ready
    DEBUG_PRINTln("System Initialing");
  }
}

void GPIO_init() {
  pinMode(GPI_ADC_BAT, INPUT);
  pinMode(GPO_SSPI_SW, OUTPUT);
  pinMode(GPO_I2C_SW, OUTPUT);
  pinMode(GPO_DSP_SW, OUTPUT);
  pinMode(GPO_SD_SW, OUTPUT);
  pinMode(GPI_SDD, INPUT);
  pinMode(GPI_BT0, INPUT);

  pinMode(TEMP_CS0, OUTPUT);
  pinMode(TEMP_CS1, OUTPUT);
  pinMode(TEMP_CS2, OUTPUT);
  pinMode(TEMP_CS3, OUTPUT);
  pinMode(TEMP_CS4, OUTPUT);
  pinMode(TEMP_CS5, OUTPUT);
  pinMode(TEMP_CS6, OUTPUT);
  pinMode(TEMP_CS7, OUTPUT);

  pinMode(LEDS_PIN, OUTPUT);

  digitalWrite(GPO_SSPI_SW, HIGH);  // 8x Temp sensor poweroff
  digitalWrite(GPO_I2C_SW, HIGH);   // 3X Pressure sensor poweroff
  digitalWrite(GPO_DSP_SW, HIGH);   // LCD poweroff
  digitalWrite(GPO_SD_SW, HIGH);    // SD card poweroff

  digitalWrite(GPO_I2CE_RES, HIGH);  // Pull HIGH I2C Expander Reset Pin, or I2C bus won't work

  digitalWrite(TEMP_CS0, HIGH);  // 8x Temp sensor un-selected
  digitalWrite(TEMP_CS1, HIGH);
  digitalWrite(TEMP_CS2, HIGH);
  digitalWrite(TEMP_CS3, HIGH);
  digitalWrite(TEMP_CS4, HIGH);
  digitalWrite(TEMP_CS5, HIGH);
  digitalWrite(TEMP_CS6, HIGH);
  digitalWrite(TEMP_CS7, HIGH);
}
